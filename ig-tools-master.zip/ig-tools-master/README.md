Based on https://github.com/jrxuii/igbotmay
.


Tutor Termux (Fresh) :
  1. pkg install nodejs-lts
  2. pkg install git
  3. pkg install bash
  4. pkg install php
  5. git clone https://github.com/issaanoorendra/ig-tools
  6. cd ig-tools
  7. unzip node_modules
  8. node ig.js (Buat FFT) / node unf.js (Buat unfollow not following) / node unfollall.js (Buat Unfollow All)
 
 Tutor Termux (Udah Pernah Pake Nodejs yg bukan LTS)
  1. pkg uninstall nodejs
  2. pkg install nodejs-lts
  3. pkg install git
  4. pkg install bash
  5. pkg install php
  6. git clone https://github.com/issaanoorendra/ig-tools
  7. cd ig-tools
  8. unzip node_modules
  9. node ig.js (Buat FFT) / node unf.js (Buat unfollow not following) / node unfollall.js (Buat Unfollow All)
  
  Tutor C9.io
  1. nvm install node
  2. git clone https://github.com/issaanoorendra/ig-tools
  3. cd ig-tools
  4. unzip node_modules
  5. node ig.js (Buat FFT) / node unf.js (Buat unfollow not following) / node unfollall.js (Buat Unfollow All)
  
